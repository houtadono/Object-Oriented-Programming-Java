package danhsachsinhvien1;
import java.io.*;
import java.text.*;
import java.util.*;

public class SinhVien implements Serializable{
    private String ma,ten,lop;
    private Date ngaysinh;
    private float gpa;
//    private static int id=1;
    
    public SinhVien(int id,String tenSV, String lopSV, String ngaySinh, float gpa) throws ParseException {
        this.ma = String.format("B20DCCN%03d", id);
        this.ten = tenSV;
        this.lop = lopSV;
        this.ngaysinh = new SimpleDateFormat("dd/MM/yyyy").parse(ngaySinh);
        this.gpa = gpa;
    }
    
    @Override
    public String toString(){
        return ma+' '+ ten+' '+lop+' '+new SimpleDateFormat("dd/MM/yyyy").format(ngaysinh)+' '+String.format("%.2f", gpa);
    }
}