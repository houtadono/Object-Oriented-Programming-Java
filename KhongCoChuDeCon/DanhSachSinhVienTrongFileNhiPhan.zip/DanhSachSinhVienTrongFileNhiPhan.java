package danhsachsinhvien1;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
/**
 *
 * @author Houta
 */
public class DanhSachSinhVienTrongFileNhiPhan {
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        FileInputStream FileIS = new FileInputStream("SV.in");
        ObjectInputStream is = new ObjectInputStream(FileIS);
        ArrayList<SinhVien> b = (ArrayList<SinhVien>) is.readObject();
        for(SinhVien tmp:b)
            System.out.println(tmp);
    }
}